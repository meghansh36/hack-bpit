"""
I am expecting following inputs 
    1. Service Type:Type of Organ
    2. StateName
    3. Service Area of Organ Provider: area of operation/proximity for an organ donation organisation
    4. CityZipCode
    
    Please maintain this order of input
"""

from sklearn.externals import joblib
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import numpy as np

#encoder for conversion of output
label_encoder=joblib.load('search_encoder_file.json')

#model for predictions
random_forest_classifier=joblib.load('search_random_forest_files.json')

"""
Dummy data:
    ServiceType StateName OPOServiceArea      CityStateZipCode
    Heart       Alabama   Alabama: Jefferson  Birmingham, AL 35233
"""
training_point=['Heart','Alabama','Alabama: Jefferson','Birmingham, AL 35233']
training_point=np.array(training_point)
print(label_encoder.transform(training_point))
#print(random_forest_classifier.predict(training_point))

